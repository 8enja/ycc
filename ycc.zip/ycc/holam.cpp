#include <iostream>
using namespace std;

int main(){
    std::cout << "La razita no se cansa de ganar!\n";
    return 0;
} 
