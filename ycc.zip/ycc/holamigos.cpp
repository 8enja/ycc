#include <iostream>
using namespace std;

int main(){
    std::cout << "¡Qué noche 😂 tan maravillosa!\n";
    std::cout << "¡La Razita gloriosa no se cansa de ganar! :D\n";
    std::cout << "te amo tanto, Luz de mi vida\n";
    return 0;
} 
 int main(){
    std::cout << "¡La Razita gloriosa no se cansa de ganar! :D\n";
    std::cout << "te amo tanto, Luz de mi vida\n";
    return 0;
 }



 int main( ){
    
 }